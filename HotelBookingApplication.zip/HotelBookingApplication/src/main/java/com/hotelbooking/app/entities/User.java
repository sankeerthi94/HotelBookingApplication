package com.hotelbooking.app.entities;

public class User {
	private int user_id;
	private String user_name;
	private String email;
	private String password;
	private String role;
	private String mobile;
	private String address;
}
