package com.hotelbooking.app.entities;

public class Flight {
	
	private int company_id;
	private String companyName;
	private String description;
	private double fairPrice;
	private String email;
	private String phone1;
	private String phone2;
	private String website;

}
