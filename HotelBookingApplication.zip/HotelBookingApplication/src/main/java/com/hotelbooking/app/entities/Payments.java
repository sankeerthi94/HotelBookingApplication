package com.hotelbooking.app.entities;

public class Payments {
	private int payment_id;
	private int booking_id;
	private int transaction_id;
}
