package com.hotelbooking.app.entities;

public class Transactions {
	private int transaction_id;
	private double amount;
}
