package com.hotelbooking.app.exceptions;

public class PaymentsNotFoundException extends Exception{

}
