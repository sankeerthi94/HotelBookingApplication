package com.hotelbooking.app.exceptions;

public class UserNotFoundException extends Exception{

}
