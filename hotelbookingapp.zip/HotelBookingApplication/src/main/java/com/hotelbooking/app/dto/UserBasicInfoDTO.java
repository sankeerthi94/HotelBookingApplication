package com.hotelbooking.app.dto;

public class UserBasicInfoDTO {

	
	private String user_name;
	private String password;
	private String email;
	private String role;
	private long mobile;
	private String address;
	public UserBasicInfoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public long getMobile() {
		return mobile;
	}

	public void setMobile(long l) {
		this.mobile = l;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public String isRole() {
		return role;
	}
	public void setRole(String string) {
		this.role = string;
	}
	
	
}
