package com.hotelbooking.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.hotelbooking.app.dto.UserBasicInfoDTO;
import com.hotelbooking.app.dto.UserSavePostDTO;
import com.hotelbooking.app.entities.User;

@Service
public interface IUserService {
	public UserBasicInfoDTO addUser(UserSavePostDTO userdto);
	public User updateUser(User user_id);
	public boolean removeUser(int user_id);
	public List<User> showAllUsers();
	public Optional<User> showUser(int user_id);
}

