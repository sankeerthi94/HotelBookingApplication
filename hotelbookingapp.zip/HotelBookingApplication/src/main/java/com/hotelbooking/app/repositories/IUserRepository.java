package com.hotelbooking.app.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hotelbooking.app.entities.User;


public interface IUserRepository extends CrudRepository<User,Integer>, CustomUserRepository{
	
}

