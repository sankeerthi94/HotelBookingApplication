package com.hotelbooking.app.util;

import org.springframework.stereotype.Component;

import com.hotelbooking.app.dto.UserBasicInfoDTO;
import com.hotelbooking.app.dto.UserSavePostDTO;
import com.hotelbooking.app.entities.User;

@Component
public class UserDTOConversionClass {

	
	public UserBasicInfoDTO getUserBasicInfoDTO(User user)
	{
		UserBasicInfoDTO dtobj=new UserBasicInfoDTO();
		dtobj.setUser_name(user.getUser_name());
		dtobj.setPassword(user.getPassword());
		dtobj.setEmail(user.getEmail());
		dtobj.setRole(user.getRole());
		dtobj.setMobile(user.getMobile());
		dtobj.setAddress(user.getAddress());
		
		
		return dtobj;
	}
	
	public User getUserfromPostUserDTO(UserSavePostDTO dto)
	{
		User u=new User();
		u.setUser_name(dto.getUser_name());
		u.setPassword(dto.getPassword());
		u.setEmail(dto.getEmail());
		u.setRole(dto.getRole());
		u.setMobile(dto.getMobile());
		u.setAddress(dto.getAddress());
		return u;
	}
}
