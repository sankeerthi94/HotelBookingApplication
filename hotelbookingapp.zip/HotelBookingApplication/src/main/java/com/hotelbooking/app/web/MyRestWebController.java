package com.hotelbooking.app.web;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotelbooking.app.dto.UserBasicInfoDTO;
import com.hotelbooking.app.dto.UserSavePostDTO;
import com.hotelbooking.app.entities.User;

import com.hotelbooking.app.service.IUserService;

@RestController
@RequestMapping("/app")
@Validated
public class MyRestWebController {

	
	@Autowired
	IUserService service;
	
	@GetMapping("/user/{user_id}")
	public Optional<User> getUserInfo(@PathVariable int user_id)
	{
		return service.showUser(user_id);
	}
	@GetMapping("/users")
	public List<User> getAllUsers()
	{
		return service.showAllUsers();
	}
	
	
	
	@DeleteMapping("/duser/{user_id}")
	public boolean deleteUserByID(@PathVariable int user_id) {
		return service.removeUser(user_id);	
	}
	
	@PostMapping("/user")
	public ResponseEntity< UserBasicInfoDTO> saveAccount(@RequestBody @Valid UserSavePostDTO a)
			 
	{
		
		
		
		
		 UserBasicInfoDTO dto =  service.addUser(a);
		return new ResponseEntity< UserBasicInfoDTO>(dto,HttpStatus.OK);
	}
	
}
