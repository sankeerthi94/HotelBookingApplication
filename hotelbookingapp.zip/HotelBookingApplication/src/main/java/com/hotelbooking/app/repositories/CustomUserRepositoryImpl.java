package com.hotelbooking.app.repositories;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotelbooking.app.entities.Hotel;
import com.hotelbooking.app.entities.User;



public class CustomUserRepositoryImpl implements CustomUserRepository{

	
	
	@Autowired
	 EntityManager entityManager;
	
	@Override
	public List<String> getprevioustravelHistory(int user_id) {
		// TODO Auto-generated method stub
		Session session = entityManager.unwrap(Session.class);
	    // select * from AccountTable where cityName = 'dffd';
	    String queryString = "select city from hotel h inner join BookingDetails d on h.hotel_id = d.hotel_id inner join user u on u.user_id = d.user_id";
	    
	    Query<String> query = session.createQuery(queryString);
	    query.setString(user_id, "user_id");
	    
	    List<String>  list = (List<String>) query.getResultList();
	    
	    // code to fetch data from DB using JPQL
	    
	    if(list != null)
	    {
	      return list;
	    }
	    else
	    {
	      throw new javax.persistence.NoResultException("City Name Records Not In The DB");
	    }
		//return null;
	}

	

	
	@Override
	public List<Hotel> gethotelLocationWise(String city) {
		// TODO Auto-generated method stub
		Session session = entityManager.unwrap(Session.class);
	    // select * from AccountTable where cityName = 'dffd';
	    String queryString = "select city from hotel a where a.city=city";
	    
	    Query<Hotel> query = session.createQuery(queryString);
	    query.setString( city,"city");
	    
	    List<Hotel>  list = (List<Hotel>) query.getResultList();
	    
	    // code to fetch data from DB using JPQL
	    
	    if(list != null)
	    {
	      return list;
	    }
	    else
	    {
	      throw new javax.persistence.NoResultException("No Hotel is available in "+city);
	    }
		
	}

}
