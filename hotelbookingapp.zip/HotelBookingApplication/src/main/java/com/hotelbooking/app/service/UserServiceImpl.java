package com.hotelbooking.app.service;

import java.util.List;
import java.util.Optional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbooking.app.dto.UserBasicInfoDTO;
import com.hotelbooking.app.dto.UserSavePostDTO;
import com.hotelbooking.app.entities.User;
import com.hotelbooking.app.repositories.IUserRepository;
import com.hotelbooking.app.util.UserDTOConversionClass;


@Service
public class UserServiceImpl implements IUserService{

	
	@Autowired
	IUserRepository userReposotory;
	
	@Autowired
	UserDTOConversionClass dtoconversion;
	
	
	@Override
	public UserBasicInfoDTO addUser(UserSavePostDTO userdto) {
		// TODO Auto-generated method stub
		User u=dtoconversion.getUserfromPostUserDTO(userdto);
		User saveobj=userReposotory.save(u);
		UserBasicInfoDTO obj=dtoconversion.getUserBasicInfoDTO(saveobj);
		return obj;
	}

	@Override
	public User updateUser(User user_id) {
		// TODO Auto-generated method stub
		
		return userReposotory.save(user_id);
		
	}

	@Override
	public boolean removeUser(int user_id) {
		// TODO Auto-generated method stub
		userReposotory.deleteById(user_id);
		return true;
		
	}

	@Override
	public List<User> showAllUsers() {
		// TODO Auto-generated method stub
		List<User> l=(List<User>) userReposotory.findAll();
		return l;
	}

	@Override
	public Optional<User> showUser(int user_id) {
		// TODO Auto-generated method stub
		Optional<User> l1=(Optional<User>) userReposotory.findById(user_id);
		return l1;
		 
	}
	

}
