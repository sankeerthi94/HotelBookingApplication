package com.hotelbooking.app.exceptions;

public class BookingDetailsNotFoundException extends Exception{

}
