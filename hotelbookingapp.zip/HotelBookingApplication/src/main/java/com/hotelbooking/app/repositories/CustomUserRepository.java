package com.hotelbooking.app.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.hotelbooking.app.entities.Hotel;
import com.hotelbooking.app.entities.User;

@Repository
public interface CustomUserRepository {

public List<String> getprevioustravelHistory(int user_id);
	
	public List<Hotel> gethotelLocationWise(String city);
}
