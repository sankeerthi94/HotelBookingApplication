package com.hotelbooking.app.service;

import com.hotelbooking.app.entities.Payments;

public interface IPaymentService {
	public Payments addPayment(Payments payment);
}

