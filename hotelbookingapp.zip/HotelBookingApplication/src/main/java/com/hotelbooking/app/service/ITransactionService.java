package com.hotelbooking.app.service;

import com.hotelbooking.app.entities.Transactions;

public interface ITransactionService {
	public Transactions addTransaction(Transactions transaction);
}
